package com.enviro.assessment.grad001.siyathandazamqhamane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan(basePackages = "com.*")
@SpringBootApplication
public class SiyathandazamqhamaneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiyathandazamqhamaneApplication.class, args);
	}
}
