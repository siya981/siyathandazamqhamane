package com.enviro.assessment.grad001.siyathandazamqhamane.mapper;

public class ResponseMapper {
}